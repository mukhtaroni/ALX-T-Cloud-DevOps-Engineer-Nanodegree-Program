I have created a snap shot of the different steps and saved this in a folder called 'steps procedure'
Please find below my CloudFront domain name,the website-endpoint and the bucket object via its S3 object URL, Respectively.
https://d2lr86q7a1swmy.cloudfront.net
http://mukhtaronis3project1.s3-website-us-east-1.amazonaws.com/
https://mukhtaronis3project1.s3.amazonaws.com/index.html